import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {
  faHtml5,
  faCss3Alt,
  faJs,
  faReact,
  faPhp,
} from '@fortawesome/free-brands-svg-icons';
import { faDatabase, faCode } from '@fortawesome/free-solid-svg-icons';
import { motion } from 'framer-motion';

export default function Skills() {
  const skills = [
    { name: 'HTML', icon: faHtml5, color: 'text-orange-500' },
    { name: 'CSS', icon: faCss3Alt, color: 'text-blue-500' },
    { name: 'JavaScript', icon: faJs, color: 'text-yellow-500' },
    {
      name: 'Tailwind CSS',
      icon: (
        <img
          src="/images/skills/tailwind.svg"
          alt="Tailwind CSS"
          className="h-16 w-16 mx-auto"
        />
      ),
      color: '', // No color needed for external SVG
    },
    { name: 'React', icon: faReact, color: 'text-blue-400' },
    { name: 'PHP', icon: faPhp, color: 'text-indigo-500' },
    { name: 'MySQL', icon: faDatabase, color: 'text-teal-500' },
    { name: 'Laravel', icon: faCode, color: 'text-red-500' }, // Using faCode as a placeholder
  ];

  const container = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { delayChildren: 0.3, staggerChildren: 0.2 },
    },
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5, ease: 'easeInOut' },
    },
  };

  return (
    <section id="skills" className="py-20 bg-gradient-to-r from-gray-100 to-gray-200 dark:from-gray-800 dark:to-gray-900">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-bold text-center mb-16 text-gray-900 dark:text-white">
          Technical Skills
        </h2>
        <motion.div
          className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8"
          variants={container}
          initial="hidden"
          animate="visible"
        >
          {skills.map((skill) => (
            <motion.div
              key={skill.name}
              className="relative group rounded-lg bg-white dark:bg-gray-700 p-6 shadow-md hover:shadow-lg transition duration-300"
              variants={item}
            >
              <div className="flex justify-center items-center h-24 w-24 mx-auto mb-4">
                {typeof skill.icon === 'object' && !skill.icon.props ? ( // Check if it's a FontAwesome icon
                  <FontAwesomeIcon icon={skill.icon} className={`h-20 w-20 ${skill.color}`} />
                ) : (
                  skill.icon // Render custom icons (e.g., Tailwind SVG)
                )}
              </div>
              <span className="block text-center text-lg font-medium text-gray-900 dark:text-white transition duration-300 group-hover:text-indigo-500">
                {skill.name}
              </span>
              <span className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 text-white bg-gray-900 dark:bg-gray-700 text-xs rounded py-1 px-2 opacity-0 group-hover:opacity-100 transition duration-300 z-10">
                {skill.name}
              </span>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
