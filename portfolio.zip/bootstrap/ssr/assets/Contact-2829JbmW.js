import { jsx, jsxs } from "react/jsx-runtime";
import "react";
import { Mail, Phone } from "lucide-react";
function Contact() {
  return /* @__PURE__ */ jsx("section", { id: "contact", className: "py-20 bg-gray-50 dark:bg-gray-800", children: /* @__PURE__ */ jsxs("div", { className: "container mx-auto px-4", children: [
    /* @__PURE__ */ jsx("h2", { className: "text-3xl font-bold text-center mb-12 text-gray-900 dark:text-white", children: "Get In Touch" }),
    /* @__PURE__ */ jsxs("div", { className: "max-w-2xl mx-auto", children: [
      /* @__PURE__ */ jsxs(
        "form",
        {
          action: "https://formspree.io/f/xyzkdyjj",
          method: "POST",
          className: "space-y-6",
          children: [
            /* @__PURE__ */ jsx("input", { type: "hidden", name: "_formname", value: "contact-form" }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx(
                "label",
                {
                  htmlFor: "name",
                  className: "block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1",
                  children: "Name"
                }
              ),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "text",
                  id: "name",
                  name: "name",
                  className: "w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500",
                  required: true
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx(
                "label",
                {
                  htmlFor: "email",
                  className: "block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1",
                  children: "Email"
                }
              ),
              /* @__PURE__ */ jsx(
                "input",
                {
                  type: "email",
                  id: "email",
                  name: "email",
                  className: "w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500",
                  required: true
                }
              )
            ] }),
            /* @__PURE__ */ jsxs("div", { children: [
              /* @__PURE__ */ jsx(
                "label",
                {
                  htmlFor: "message",
                  className: "block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1",
                  children: "Message"
                }
              ),
              /* @__PURE__ */ jsx(
                "textarea",
                {
                  id: "message",
                  name: "message",
                  rows: 5,
                  className: "w-full px-4 py-2 rounded-lg border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500",
                  required: true
                }
              )
            ] }),
            /* @__PURE__ */ jsx("div", { className: "text-center", children: /* @__PURE__ */ jsx(
              "button",
              {
                type: "submit",
                className: "bg-blue-600 text-white px-8 py-3 rounded-full font-semibold hover:bg-blue-700 transition-colors",
                children: "Send Message"
              }
            ) })
          ]
        }
      ),
      /* @__PURE__ */ jsxs("div", { className: "mt-12 text-center", children: [
        /* @__PURE__ */ jsx("h3", { className: "text-xl font-semibold text-gray-900 dark:text-white mb-4", children: "Or reach out directly:" }),
        /* @__PURE__ */ jsxs("div", { className: "flex flex-col sm:flex-row justify-center items-center gap-6", children: [
          /* @__PURE__ */ jsxs(
            "a",
            {
              href: "mailto:khrashadul@gmail.com",
              className: "flex items-center gap-2 text-gray-700 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors",
              children: [
                /* @__PURE__ */ jsx(Mail, { className: "w-6 h-6" }),
                /* @__PURE__ */ jsx("span", { children: "khrashadul@gmail.com" })
              ]
            }
          ),
          /* @__PURE__ */ jsxs(
            "a",
            {
              href: "tel:+8801870207601",
              className: "flex items-center gap-2 text-gray-700 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors",
              children: [
                /* @__PURE__ */ jsx(Phone, { className: "w-6 h-6" }),
                /* @__PURE__ */ jsx("span", { children: "+8801870207601" })
              ]
            }
          )
        ] })
      ] })
    ] })
  ] }) });
}
export {
  Contact as default
};
