import { jsxs, jsx } from "react/jsx-runtime";
import { Github, Linkedin, Mail, Phone } from "lucide-react";
function Header() {
  return /* @__PURE__ */ jsxs("header", { id: "header", className: "min-h-screen flex items-center justify-center relative bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-gray-900 dark:to-gray-800", children: [
    /* @__PURE__ */ jsx("link", { rel: "icon", href: "/images/favicon.ico", type: "image/x-icon" }),
    /* @__PURE__ */ jsxs("div", { className: "container mx-auto px-4 py-16 text-center", children: [
      /* @__PURE__ */ jsx(
        "img",
        {
          src: "/images/pf/sho5.jpg",
          alt: "Profile",
          className: "w-60 h-60 rounded-full mx-auto mb-8 object-cover shadow-lg"
        }
      ),
      /* @__PURE__ */ jsx("h1", { className: "text-5xl font-bold mb-4 text-gray-900 dark:text-white", children: "Rashadul Islam" }),
      /* @__PURE__ */ jsx("h2", { className: "text-2xl text-blue-600 dark:text-blue-400 mb-6", children: "Full Stack Web Developer" }),
      /* @__PURE__ */ jsx("p", { className: "text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto mb-8", children: "Passionate about creating innovative web solutions with modern technologies. Specialized in PHP, Laravel, React, and building scalable applications." }),
      /* @__PURE__ */ jsxs("div", { className: "flex justify-center gap-6 mb-8", children: [
        /* @__PURE__ */ jsx(
          "a",
          {
            href: "https://github.com/khshourav",
            className: "p-3 rounded-full bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors",
            "aria-label": "GitHub",
            children: /* @__PURE__ */ jsx(Github, { className: "w-8 h-8" })
          }
        ),
        /* @__PURE__ */ jsx(
          "a",
          {
            href: "https://www.linkedin.com/in/khrashadul",
            className: "p-3 rounded-full bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors",
            "aria-label": "LinkedIn",
            children: /* @__PURE__ */ jsx(Linkedin, { className: "w-8 h-8" })
          }
        ),
        /* @__PURE__ */ jsx(
          "a",
          {
            href: "mailto:khrashadul@gmail.com",
            className: "p-3 rounded-full bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors",
            "aria-label": "Email",
            children: /* @__PURE__ */ jsx(Mail, { className: "w-8 h-8" })
          }
        ),
        /* @__PURE__ */ jsx(
          "a",
          {
            href: "tel:+8801870207601",
            className: "p-3 rounded-full bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors",
            "aria-label": "Call",
            children: /* @__PURE__ */ jsx(Phone, { className: "w-8 h-8" })
          }
        )
      ] }),
      /* @__PURE__ */ jsx(
        "a",
        {
          href: "#contact",
          className: "inline-block bg-blue-600 text-white px-8 py-3 rounded-full font-semibold hover:bg-blue-700 transition-colors transform hover:scale-105",
          children: "Contact Me"
        }
      )
    ] })
  ] });
}
export {
  Header as default
};
