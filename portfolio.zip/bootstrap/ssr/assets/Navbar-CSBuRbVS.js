import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { X, Menu } from "lucide-react";
import { useState, useEffect } from "react";
import ThemeToggle from "./ThemeToggle-CE9o4J-l.js";
function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);
  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setIsOpen(false);
    }
  };
  return /* @__PURE__ */ jsx(
    "nav",
    {
      className: `fixed top-0 w-full z-50 transition-all duration-300 ${isScrolled ? "bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm shadow-lg" : "bg-transparent"}`,
      role: "navigation",
      "aria-label": "Main navigation",
      children: /* @__PURE__ */ jsxs("div", { className: "container mx-auto px-4", children: [
        /* @__PURE__ */ jsxs("div", { className: "flex items-center justify-between h-16", children: [
          /* @__PURE__ */ jsx(
            "button",
            {
              onClick: () => scrollToSection("header"),
              className: "text-xl font-bold text-gray-900 dark:text-white hover:text-blue-600 dark:hover:text-blue-400 transition-colors",
              children: "Rashadul Islam"
            }
          ),
          /* @__PURE__ */ jsxs("div", { className: "hidden md:flex items-center space-x-8", children: [
            /* @__PURE__ */ jsx(NavLinks, { scrollToSection }),
            /* @__PURE__ */ jsx(ThemeToggle, {})
          ] }),
          /* @__PURE__ */ jsxs("div", { className: "md:hidden flex items-center", children: [
            /* @__PURE__ */ jsx(ThemeToggle, {}),
            /* @__PURE__ */ jsx(
              "button",
              {
                onClick: () => setIsOpen(!isOpen),
                className: "ml-4 p-2 rounded-lg text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors",
                "aria-expanded": isOpen,
                "aria-label": "Toggle navigation menu",
                children: isOpen ? /* @__PURE__ */ jsx(X, { className: "h-6 w-6" }) : /* @__PURE__ */ jsx(Menu, { className: "h-6 w-6" })
              }
            )
          ] })
        ] }),
        /* @__PURE__ */ jsx(
          "div",
          {
            className: `md:hidden transition-all duration-300 ease-in-out ${isOpen ? "max-h-64 opacity-100" : "max-h-0 opacity-0 pointer-events-none"}`,
            children: /* @__PURE__ */ jsx("div", { className: "py-4 space-y-4", children: /* @__PURE__ */ jsx(MobileNavLinks, { scrollToSection }) })
          }
        )
      ] })
    }
  );
}
function NavLinks({ scrollToSection }) {
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    ["skills", "projects", "about", "contact"].map((section) => /* @__PURE__ */ jsx(
      "button",
      {
        onClick: () => scrollToSection(section),
        className: "text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 capitalize transition-colors",
        children: section
      },
      section
    )),
    /* @__PURE__ */ jsx(
      "a",
      {
        href: "/cv/Rashadul_Islam_CV_2025.pdf",
        className: "inline-block bg-blue-600 text-white px-6 py-2 rounded-full font-semibold hover:bg-blue-700 transition-colors",
        target: "_blank",
        rel: "noopener noreferrer",
        children: "Resume"
      }
    )
  ] });
}
function MobileNavLinks({ scrollToSection }) {
  return /* @__PURE__ */ jsxs("div", { className: "flex flex-col space-y-4", children: [
    ["skills", "projects", "about", "contact"].map((section) => /* @__PURE__ */ jsx(
      "button",
      {
        onClick: () => scrollToSection(section),
        className: "text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 capitalize transition-colors text-left px-4",
        children: section
      },
      section
    )),
    /* @__PURE__ */ jsx(
      "a",
      {
        href: "/cv/Rashadul_Islam_CV_2025.pdf",
        className: "inline-block bg-blue-600 text-white px-6 py-2 rounded-full font-semibold hover:bg-blue-700 transition-colors text-left",
        target: "_blank",
        rel: "noopener noreferrer",
        children: "Resume"
      }
    )
  ] });
}
export {
  Navbar as default
};
