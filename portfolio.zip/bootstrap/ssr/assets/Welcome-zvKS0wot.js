import { jsxs, jsx } from "react/jsx-runtime";
import "@inertiajs/react";
import About from "./About-BW61braL.js";
import Contact from "./Contact-2829JbmW.js";
import Navbar from "./Navbar-CSBuRbVS.js";
import Header from "./Header-Cj0HGTJc.js";
import Skills from "./Skills-BI7txqTP.js";
import Projects from "./Projects-8W2rRI2x.js";
import ScrollToTop from "./ScrollToTop-BeiC6hif.js";
import "react";
import "lucide-react";
import "./ThemeToggle-CE9o4J-l.js";
import "@fortawesome/react-fontawesome";
import "@fortawesome/free-brands-svg-icons";
import "@fortawesome/free-solid-svg-icons";
import "framer-motion";
function Welcome() {
  return /* @__PURE__ */ jsxs("div", { className: "min-h-screen bg-white dark:bg-gray-900 transition-colors", children: [
    /* @__PURE__ */ jsx(Navbar, {}),
    /* @__PURE__ */ jsxs("main", { children: [
      /* @__PURE__ */ jsx(Header, {}),
      /* @__PURE__ */ jsx(Skills, {}),
      /* @__PURE__ */ jsx(Projects, {}),
      /* @__PURE__ */ jsx(About, {}),
      /* @__PURE__ */ jsx(Contact, {})
    ] }),
    /* @__PURE__ */ jsx(ScrollToTop, {})
  ] });
}
export {
  Welcome as default
};
