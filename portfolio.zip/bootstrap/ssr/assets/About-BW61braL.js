import { jsx, jsxs } from "react/jsx-runtime";
function About() {
  return /* @__PURE__ */ jsx("section", { id: "about", className: "py-20 bg-white dark:bg-gray-900", children: /* @__PURE__ */ jsx("div", { className: "container mx-auto px-4", children: /* @__PURE__ */ jsxs("div", { className: "max-w-3xl mx-auto", children: [
    /* @__PURE__ */ jsx("h2", { className: "text-3xl font-bold text-center mb-12 text-gray-900 dark:text-white", children: "About Me" }),
    /* @__PURE__ */ jsxs("div", { className: "prose dark:prose-invert max-w-none", children: [
      /* @__PURE__ */ jsx("p", { className: "text-gray-600 dark:text-gray-300 mb-6", children: "I am an enthusiastic and dedicated web developer with hands-on experience building impactful projects using Laravel and React. Over the past 6 months, I have developed basic to intermediate-level applications, continuously honing my skills and adopting best development practices. My passion for learning drives me to stay updated with modern web technologies." }),
      /* @__PURE__ */ jsx("h3", { className: "text-xl font-semibold mb-4 text-gray-900 dark:text-white", children: "Technical Skills" }),
      /* @__PURE__ */ jsxs("ul", { className: "list-disc pl-6 mb-6 text-gray-600 dark:text-gray-300", children: [
        /* @__PURE__ */ jsx("li", { children: "Proficient in developing applications using PHP and Laravel framework" }),
        /* @__PURE__ */ jsx("li", { children: "Experience with JavaScript frameworks like React for interactive front-end development" }),
        /* @__PURE__ */ jsx("li", { children: "Knowledge of RESTful APIs, database design, and version control systems (Git)" }),
        /* @__PURE__ */ jsx("li", { children: "Strong problem-solving skills and a focus on clean, maintainable code" })
      ] }),
      /* @__PURE__ */ jsx("h3", { className: "text-xl font-semibold mb-4 text-gray-900 dark:text-white", children: "Education" }),
      /* @__PURE__ */ jsxs("ul", { className: "list-disc pl-6 mb-6 text-gray-600 dark:text-gray-300", children: [
        /* @__PURE__ */ jsx("li", { children: "B.Sc. in Computer Science and Engineering - East West University" }),
        /* @__PURE__ */ jsx("li", { children: "Full Stack Web Development Course - Learn With Fiz" })
      ] }),
      /* @__PURE__ */ jsx("h3", { className: "text-xl font-semibold mb-4 text-gray-900 dark:text-white", children: "Work Philosophy" }),
      /* @__PURE__ */ jsx("p", { className: "text-gray-600 dark:text-gray-300 mb-6", children: "I am committed to writing clean, maintainable code and following best development practices. I thrive in collaborative environments and enjoy learning from more experienced developers. My goal is to contribute to impactful projects and grow as a Laravel developer." }),
      /* @__PURE__ */ jsx("div", { className: "text-center mt-8", children: /* @__PURE__ */ jsx(
        "a",
        {
          href: "/cv/Rashadul_Islam_CV_2025.pdf",
          className: "inline-block bg-blue-600 text-white px-6 py-2 rounded-full font-semibold hover:bg-blue-700 transition-colors",
          target: "_blank",
          rel: "noopener noreferrer",
          children: "Download Resume"
        }
      ) })
    ] })
  ] }) }) });
}
export {
  About as default
};
