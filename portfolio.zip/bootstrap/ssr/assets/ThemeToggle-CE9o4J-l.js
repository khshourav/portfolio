import { jsx } from "react/jsx-runtime";
import { Sun, Moon } from "lucide-react";
import { useState, useEffect } from "react";
function ThemeToggle() {
  const [darkMode, setDarkMode] = useState(() => {
    const savedMode = localStorage.getItem("darkMode");
    if (savedMode !== null) {
      return JSON.parse(savedMode);
    }
    return window.matchMedia("(prefers-color-scheme: dark)").matches;
  });
  useEffect(() => {
    localStorage.setItem("darkMode", JSON.stringify(darkMode));
    if (darkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [darkMode]);
  return /* @__PURE__ */ jsx(
    "button",
    {
      onClick: () => setDarkMode(!darkMode),
      className: "p-2 rounded-lg bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors",
      "aria-label": "Toggle theme",
      children: darkMode ? /* @__PURE__ */ jsx(Sun, { className: "w-5 h-5 text-yellow-500" }) : /* @__PURE__ */ jsx(Moon, { className: "w-5 h-5 text-gray-700" })
    }
  );
}
export {
  ThemeToggle as default
};
